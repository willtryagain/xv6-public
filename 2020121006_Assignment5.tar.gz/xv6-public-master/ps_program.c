#include "defs.h"
#include "syscall.h"
#include "user.h"

int main() {
	ps();
	exit();
}